<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sudoku Generator</title>
</head>
<body>
    <form action="sudoku.php" method="POST">
        <label for="difficulty">Введите сложность (0-9):</label>
        <input type="text" id="difficulty" name="difficulty" required>
        <input type="submit" value="Сгенерировать судоку">
    </form>
</body>
</html>
