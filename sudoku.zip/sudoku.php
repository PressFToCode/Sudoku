<?php

class Sudoku {
    
    private $difficulty;
    private $block = array();
    private $mask = array();
    private $rand = "";
    
    private $Reg = array();
    private $Lgn = array();
    private $col = array();
    
    public function __construct($level = 0) {
        $this->difficulty = $level;
        $this->ini();
        
        // Retrieve pre-filled data from the database based on the difficulty level
        $data = $this->getDataFromDatabase($level);
        
        // Fill the block array with the retrieved data
        for ($i = 0; $i < 9; $i++) {
            for ($j = 0; $j < 9; $j++) {
                $this->block[$i][$j] = $data[$i][$j];
                if ($data[$i][$j] != "0") {
                    $this->mask[$i][$j] = 1;
                }
            }
        }
    }
    
    private function getDataFromDatabase($level) {
        $dsn = 'mysql:host=localhost;dbname=sudoku';
        $username = 'root';
        $password = 'root';
        
        try {
            $pdo = new PDO($dsn, $username, $password);
            $stmt = $pdo->prepare('SELECT data FROM puzzles WHERE difficulty = :level');
            $stmt->bindParam(':level', $level, PDO::PARAM_INT);
            $stmt->execute();
            $data = $stmt->fetch(PDO::FETCH_ASSOC)['data'];
            
            $arrayData = [];
            for ($i = 0; $i < 9; $i++) {
                $arrayData[$i] = str_split(substr($data, $i * 9, 9));
            }
            
            return $arrayData;
        } catch (PDOException $e) {
            echo 'Database connection failed: ' . $e->getMessage();
            die();
        }
    }

    public function generate($inputs = []) {
        
        $puzzle = $this->puzzle();
        
        echo "<form method='post' action=''>";
        echo "<div style='display: flex;'>";
        echo "<table style='border-collapse:collapse;border-spacing:0;border:3px solid #000;margin-right:20px;'>";
        
        for ($i = 0; $i < 9; $i++) {
            if ($i == 2 || $i == 5) {
                $ts = 'style="border-bottom:3px solid #000;"';
            } else {
                $ts = '';
            }
            echo "<tr $ts>";
            for ($j = 0; $j < 9; $j++) {
                if ($j == 2 || $j == 5) {
                    $td = 'border-right:3px solid #000;';
                } else {
                    $td = '';
                }
                if ($this->mask[$i][$j] == 0) {
                    // Если ячейка пустая, создаем input для ввода
                    $value = isset($inputs[$i][$j]) ? $inputs[$i][$j] : '';
                    echo "<td style='width:40px;height:40px;text-align:center;border:1px solid #000;font-size: 30px;$td'>";
                    echo "<input type='text' name='cell[$i][$j]' value='$value' style='width: 100%; text-align: center;' maxlength='1'>";
                    echo "</td>";
                } else {
                    // Выводим значение из блока
                    echo "<td style='width:40px;height:40px;text-align:center;border:1px solid #000;font-size: 30px;$td'>".$puzzle[$i][$j]."</td>";
                }
            }
            echo "</tr>";
        }
        
        echo "</table>";
        
        // Кнопка "Проверить"
        echo "<input type='submit' name='check' value='Проверить' style='display:block;margin-top:20px;'>";
        echo "</form>";
    }

    public function generateWithAnswers() {
        // Получаем уровень сложности из сессии, если он был установлен
        $level = isset($_SESSION['difficulty']) ? $_SESSION['difficulty'] : 0;
    
        // Подключаемся к базе данных
        $dsn = 'mysql:host=localhost;dbname=sudoku';
        $username = 'root';
        $password = 'root';
        
        try {
            $pdo = new PDO($dsn, $username, $password);
            // Получаем данные о судоку с ответами из базы данных в зависимости от уровня сложности
            $stmt = $pdo->prepare('SELECT data FROM answers WHERE difficulty = :level');
            $stmt->bindParam(':level', $level, PDO::PARAM_INT);
            $stmt->execute();
            $data = $stmt->fetch(PDO::FETCH_ASSOC)['data'];
    
            // Преобразуем данные в судоку
            $sudoku = [];
            for ($i = 0; $i < 9; $i++) {
                $sudoku[$i] = str_split(substr($data, $i * 9, 9));
            }
    
            // Выводим судоку в виде таблицы
            echo "<table border='1' style='border-collapse:collapse;border-spacing:0;border:3px solid #000;float:left;margin-left:20px;'>";
            for ($i = 0; $i < 9; $i++) {
                echo "<tr>";
                for ($j = 0; $j < 9; $j++) {
                    echo "<td style='width:40px;height:40px;text-align:center;border:1px solid #000;font-size: 30px;'>".$sudoku[$i][$j]."</td>";
                }
                echo "</tr>";
            }
            echo "</table>";

        } catch (PDOException $e) {
            echo 'Database connection failed: ' . $e->getMessage();
        }
    }

    public function checkSolution() {
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['check'])) {
            // Получаем данные из POST запроса
            $inputs = isset($_POST['cell']) ? $_POST['cell'] : [];

            // Проверяем ответы
            $correct = $this->isCorrectSolution($inputs);

            // Отображаем результаты
            $this->displayResults($correct, $inputs);
        }
    }
    
    private function isCorrectSolution($inputs) {
        // Получаем уровень сложности из сессии
        $level = isset($_SESSION['difficulty']) ? $_SESSION['difficulty'] : 0;
        
        // Подключаемся к базе данных
        $dsn = 'mysql:host=localhost;dbname=sudoku';
        $username = 'root';
        $password = 'root';
        
        try {
            $pdo = new PDO($dsn, $username, $password);
            // Получаем данные о правильном решении из базы данных
            $stmt = $pdo->prepare('SELECT data FROM answers WHERE difficulty = :level');
            $stmt->bindParam(':level', $level, PDO::PARAM_INT);
            $stmt->execute();
            $correctData = $stmt->fetch(PDO::FETCH_ASSOC)['data'];
    
            // Преобразуем данные в массив
            $correctSolution = [];
            for ($i = 0; $i < 9; $i++) {
                $correctSolution[$i] = str_split(substr($correctData, $i * 9, 9));
            }
    
            // Проверяем, правильно ли заполнено Sudoku
            for ($i = 0; $i < 9; $i++) {
                for ($j = 0; $j < 9; $j++) {
                    // Если значение ячейки не совпадает с правильным решением, возвращаем false
                    if (isset($inputs[$i][$j]) && $inputs[$i][$j] != $correctSolution[$i][$j]) {
                        return false;
                    }
                }
            }
            // Если все ячейки заполнены верно, возвращаем true
            return true;
        } catch (PDOException $e) {
            echo 'Database connection failed: ' . $e->getMessage();
            die();
        }
    }

    private function displayResults($correct, $inputs) {
        // Отображаем результаты проверки
        if ($correct) {
            echo "<p>Поздравляем! Вы правильно решили Sudoku!</p>";
        } else {
            echo "<p>К сожалению, есть ошибки в вашем решении Sudoku. Попробуйте еще раз.</p>";
        }

        // Снова выводим таблицу, заполненную пользователем
        $this->generate($inputs);

        // Отображаем таблицу с ответами
        echo "<p>Таблица с ответами:</p>";
        $this->generateWithAnswers();
    }
    
    private function ini() {
        $this->rand = "";
        $this->coli = 0;
        
        for ($i = 0; $i <= 8; $i++) {
            for ($j = 0; $j <= 8; $j++) {
                $this->block[$i][$j] = "0";
                $this->mask[$i][$j] = 0;
                $this->rand = $this->rand.chr(97+$i).chr(48+$j);
            }
        }
        
        for ($n = 0; $n <= 8; $n++) {
            for ($m = 0; $m <= 8; $m++) {
                $this->Reg[$n][$m] = "012345678";
                $this->Lgn[$n][$m] = "012345678";
                $this->col[$n][$m] = "012345678";
            }
        }
    }

    private function puzzle() {
        
        $cut = $this->mask;
        $puzzle = array();
        
        for ($i = 0; $i < 9; $i++) {
            for ($j = 0; $j < 9; $j++) {
                if ($cut[$i][$j] == 0) {
                    $puzzle[$i][$j] = "";
                } else {
                    $puzzle[$i][$j] = $this->block[$i][$j];
                }
            }
        }
        
        return $puzzle;
    }
}

// Проверка и обработка входных данных
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['difficulty']) && is_numeric($_POST['difficulty'])) {
        $level = (int)$_POST['difficulty'];
        
        if ($level >= 0 && $level <= 9) {
            // Удаляем существующую сессию, если она есть
            session_start();
            session_destroy();
            // Создаем новую сессию
            session_start();
            
            // Создаем экземпляр класса Sudoku с выбранной сложностью
            $sudoku = new Sudoku($level);
            // Генерируем судоку на основе выбранной сложности
            $sudoku->generate();
            // Сохраняем выбранную сложность в сессии для передачи на следующую страницу
            $_SESSION['difficulty'] = $level;
        } else {
            echo "Error: Difficulty level must be between 0 and 9.";
        }
    } elseif (isset($_POST['check'])) {
        // Если нажата кнопка "Проверить"
        session_start();
        $sudoku = new Sudoku($_SESSION['difficulty']);
        $sudoku->checkSolution();
    } else {
        echo "";
    }
}
?>

<!DOCTYPE html>
    <html>
    <body>
        <!-- Кнопка для возвращения на стартовую страницу -->
        <a href="start.php">Вернуться на стартовую страницу</a>
    </body>
    </html>